import 'package:flutter/cupertino.dart';

class DownloadLabelsView extends StatelessWidget {
  const DownloadLabelsView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(),
      child: Container(),
    );
  }
}
