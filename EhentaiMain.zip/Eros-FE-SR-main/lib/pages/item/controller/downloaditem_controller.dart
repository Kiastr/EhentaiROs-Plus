// import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:get/get.dart';

class DownloadArchiverController extends GetxController {
  DownloadArchiverController(this.taskid);

  final String taskid;

  @override
  void onInit() {
    super.onInit();
  }
}
