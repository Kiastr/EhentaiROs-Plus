import 'package:get/get.dart';

class TabHomeBinding extends Bindings {
  @override
  void dependencies() {
    // logger.d('TabHomeBinding');
  }
}
