/// 模仿Java的Optional
///
/// Created by ipcjs on 2021/5/19.
// class Optional<T> {
//   const Optional(this.value);
//
//   final T? value;
//
//   bool get isPresent => value != null;
// }
