// class WatchedViewController extends DefaultTabViewController {
//   String get title => L10n.of(Get.context!).tab_watched;
//
//   @override
//   void onInit() {
//     heroTag = EHRoutes.watched;
//     super.onInit();
//   }
//
//   @override
//   FetchListClient getFetchListClient(FetchParams fetchParams) {
//     return WatchedFetchListClient(fetchParams: fetchParams);
//   }
// }
