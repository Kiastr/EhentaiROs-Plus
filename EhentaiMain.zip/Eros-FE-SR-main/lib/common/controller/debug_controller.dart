import 'package:get/get.dart';

class DebugController extends GetxController {}
