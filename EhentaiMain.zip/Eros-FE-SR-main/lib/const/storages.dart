// 设备是否第一次打开
const String STORAGE_DEVICE_ALREADY_OPEN_KEY = 'device_already_open';

const String PROFILE = 'profile';

const String HISTORY = 'history';

const String GALLERY_CACHE = 'galleryCache';

const String IS_DB_IN_SUPPORT_DIR = 'isDBinappSupportPath';

const String GS_HISTORY = 'history';
const String GS_GALLERY_CACHE = 'galleryCache';
const String GS_LOCAL_FAV = 'loaclFav';

const String BLURRED_IN_RECENT_TASK = 'blurredInRecentTasks';

const String CLEAN_VER = 'cleanVer';
