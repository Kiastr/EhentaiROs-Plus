const kIndicatorRadius = 20.0;
