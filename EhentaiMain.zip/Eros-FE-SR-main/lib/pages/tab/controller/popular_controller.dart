// class PopularViewController extends DefaultTabViewController {
//   @override
//   void onInit() {
//     heroTag = EHRoutes.popular;
//     super.onInit();
//   }
//
//   @override
//   FetchListClient getFetchListClient(FetchParams fetchParams) {
//     return PopularFetchListClient(fetchParams: fetchParams);
//   }
// }
