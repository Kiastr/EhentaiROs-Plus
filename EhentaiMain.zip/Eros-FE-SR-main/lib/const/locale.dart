const Map<String, String> languageMenu = <String, String>{
  'en_US': 'English',
  'ja_JP': '日本語',
  'ko_KR': '한국어',
  'ru_RU': 'Русский язык',
  'zh_CN': '简体中文',
  'zh_TW': '繁體中文',
};
