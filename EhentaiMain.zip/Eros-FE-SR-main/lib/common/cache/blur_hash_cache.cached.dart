// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint

part of 'blur_hash_cache.dart';

// **************************************************************************
// CachedGenerator
// **************************************************************************

abstract class _$BlurHashRepository {}

class _BlurHashRepository
    with BlurHashRepository
    implements _$BlurHashRepository {
  _BlurHashRepository();

  @override
  void clearAllData() {}
}
